package com.example.countdown;

import android.media.MediaPlayer;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {

   // Button button=findViewById(R.id.button);
    TextView textView1;
    TextView textView2;
    SeekBar seekBar;
    Boolean isactive=false;
    Button button;
    CountDownTimer countDownTimer;
public void updatetimer(int i){
    int miniutes=i/60;
    int seconds=i-miniutes*60;
    String m,s;
    m=Integer.toString(miniutes);
    s=Integer.toString(seconds);
    if(miniutes<10)
        m ="0"+Integer.toString(miniutes);
    if(seconds<10)
        s ="0"+Integer.toString(seconds);
    textView1.setText(m);
    textView2.setText(s);



}

public void reset(){



    isactive=false;
    seekBar.setEnabled(true);
    button.setText("START!");
    countDownTimer.cancel();
    seekBar.setProgress(30);
    textView1.setText("00");
    textView2.setText("45");

}
    public  void click(View view){


            if(isactive){

                reset();
            }
            else {

                seekBar.setEnabled(false);
                button.setText("STOP!");


                countDownTimer = new CountDownTimer(seekBar.getProgress() * 1000 + 100, 1000) {
                    @Override
                    public void onTick(long l) {

                        updatetimer((int) l / 1000);
                    }

                    @Override
                    public void onFinish() {
                        MediaPlayer mediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.horn);
                        mediaPlayer.start();
                        reset();
                    }
                }.start();
                isactive=true;

            }
    }





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        seekBar=findViewById(R.id.seekBar);
        textView1=findViewById(R.id.textm);
        textView2=findViewById(R.id.texts);
        button=findViewById(R.id.button);
        seekBar.setMax(600);
        seekBar.setProgress(45);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
              updatetimer(i);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

    }
}
